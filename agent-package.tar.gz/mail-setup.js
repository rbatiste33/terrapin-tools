// ══════════════════════════════════════
//  Terrapin Mail Setup
//  Configures Gmail App Password for local email sending
//  Encrypts credentials and saves to ~/.terrapin/mail-config.json
// ══════════════════════════════════════

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const os = require('os');
const readline = require('readline');
const { exec } = require('child_process');

const TERRAPIN_DIR = path.join(os.homedir(), '.terrapin');
const CONFIG_PATH = path.join(TERRAPIN_DIR, 'mail-config.json');

// ══════════════════════════════════════
//  ENCRYPTION
// ══════════════════════════════════════
const ALGO = 'aes-256-gcm';

function getMachineKey() {
  const seed = os.hostname() + ':' + os.userInfo().username + ':terrapin-mail-2026';
  return crypto.createHash('sha256').update(seed).digest();
}

function encrypt(data) {
  const key = getMachineKey();
  const iv = crypto.randomBytes(16);
  const cipher = crypto.createCipheriv(ALGO, key, iv);
  let encrypted = cipher.update(JSON.stringify(data), 'utf8', 'hex');
  encrypted += cipher.final('hex');
  const tag = cipher.getAuthTag();
  return JSON.stringify({
    iv: iv.toString('hex'),
    content: encrypted,
    tag: tag.toString('hex')
  });
}

// ══════════════════════════════════════
//  PROMPTS
// ══════════════════════════════════════
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

function ask(question) {
  return new Promise(resolve => rl.question(question, resolve));
}

// ══════════════════════════════════════
//  SETUP
// ══════════════════════════════════════
async function setup() {
  console.log('');
  console.log('  🐢 Terrapin Mail Setup');
  console.log('  ─────────────────────────');
  console.log('');
  console.log('  This sets up Gmail to send emails from your Terrapin tools.');
  console.log('  You need a Gmail App Password — not your regular password.');
  console.log('');

  // Step 1: Gmail address
  const email = await ask('  Your Gmail address: ');
  if (!email || !email.includes('@')) {
    console.log('\n  ✗ Invalid email. Try again.\n');
    rl.close();
    process.exit(1);
  }

  // Step 2: Open App Password page
  console.log('');
  console.log('  Opening Gmail App Passwords page...');
  console.log('  If it doesn\'t open, go to: https://myaccount.google.com/apppasswords');
  console.log('');
  console.log('  Steps:');
  console.log('    1. Sign in to your Google account');
  console.log('    2. Create a new App Password (name it "Terrapin")');
  console.log('    3. Copy the 16-character password');
  console.log('');

  // Open browser
  const url = 'https://myaccount.google.com/apppasswords';
  const platform = process.platform;
  if (platform === 'darwin') exec(`open "${url}"`);
  else if (platform === 'win32') exec(`start "${url}"`);
  else exec(`xdg-open "${url}"`);

  // Step 3: App Password
  const appPassword = await ask('  Paste your App Password here: ');
  const cleaned = appPassword.replace(/\s/g, '');
  if (!cleaned || cleaned.length < 10) {
    console.log('\n  ✗ That doesn\'t look right. App Passwords are usually 16 characters.\n');
    rl.close();
    process.exit(1);
  }

  // Step 4: Encrypt and save
  console.log('');
  console.log('  Encrypting credentials...');

  if (!fs.existsSync(TERRAPIN_DIR)) {
    fs.mkdirSync(TERRAPIN_DIR, { recursive: true });
  }

  const config = { email: email.trim(), appPassword: cleaned };
  const encrypted = encrypt(config);
  fs.writeFileSync(CONFIG_PATH, encrypted);
  fs.chmodSync(CONFIG_PATH, 0o600); // Owner read/write only

  console.log(`  Saved to: ${CONFIG_PATH}`);
  console.log('');

  // Step 5: Test send
  console.log('  Sending test email...');

  try {
    const nodemailer = require('nodemailer');
    const transporter = nodemailer.createTransport({
      host: 'smtp.gmail.com',
      port: 465,
      secure: true,
      auth: { user: config.email, pass: config.appPassword }
    });

    await transporter.verify();

    await transporter.sendMail({
      from: config.email,
      to: config.email,
      subject: 'Terrapin Mail — Setup Complete 🐢',
      text: 'Your Terrapin mail server is configured and ready to send.\n\nThis is a test email from your local machine.\n\n— terrapin.tools',
      html: '<p>Your Terrapin mail server is configured and ready to send.</p><p>This is a test email from your local machine.</p><p style="color:#6B6B6B;">— terrapin.tools</p>'
    });

    console.log('');
    console.log('  ─────────────────────────');
    console.log('  ✓ Setup complete!');
    console.log(`  ✓ Test email sent to ${config.email}`);
    console.log('  ✓ Credentials encrypted and saved');
    console.log('');
    console.log('  To start the mail server:');
    console.log('    npm run mail');
    console.log('');
  } catch (e) {
    console.log('');
    console.log('  ✗ Connection failed: ' + e.message);
    console.log('');
    console.log('  Common fixes:');
    console.log('    - Make sure 2-factor auth is ON for your Google account');
    console.log('    - Make sure you created an App Password, not using your regular password');
    console.log('    - Check the App Password has no extra spaces');
    console.log('');
    console.log('  Your config was saved. Fix the issue and run setup again.');
    console.log('');
  }

  rl.close();
}

setup();
