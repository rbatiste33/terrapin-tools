// ══════════════════════════════════════
//  Terrapin Mail Server
//  Local SMTP relay — localhost:3001
//  Sends via Gmail App Password
//  Never touches the internet except to send your email
// ══════════════════════════════════════

const express = require('express');
const nodemailer = require('nodemailer');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const os = require('os');

const PORT = 3001;
const TERRAPIN_DIR = path.join(os.homedir(), '.terrapin');
const CONFIG_PATH = path.join(TERRAPIN_DIR, 'mail-config.json');
const LOG_PATH = path.join(TERRAPIN_DIR, 'mail-log.txt');

// ══════════════════════════════════════
//  ENCRYPTION
// ══════════════════════════════════════
const ALGO = 'aes-256-gcm';

function getMachineKey() {
  // Derive a stable key from hostname + username — unique per machine, no external dependency
  const seed = os.hostname() + ':' + os.userInfo().username + ':terrapin-mail-2026';
  return crypto.createHash('sha256').update(seed).digest();
}

function decrypt(encrypted) {
  const key = getMachineKey();
  const data = JSON.parse(encrypted);
  const decipher = crypto.createDecipheriv(ALGO, key, Buffer.from(data.iv, 'hex'));
  decipher.setAuthTag(Buffer.from(data.tag, 'hex'));
  let decrypted = decipher.update(data.content, 'hex', 'utf8');
  decrypted += decipher.final('utf8');
  return JSON.parse(decrypted);
}

// ══════════════════════════════════════
//  LOAD CONFIG
// ══════════════════════════════════════
function loadConfig() {
  if (!fs.existsSync(CONFIG_PATH)) {
    console.error('\n  Mail not configured. Run: npm run setup-mail\n');
    process.exit(1);
  }
  const raw = fs.readFileSync(CONFIG_PATH, 'utf8');
  return decrypt(raw);
}

// ══════════════════════════════════════
//  LOGGING
// ══════════════════════════════════════
function logSend(to, subject, success, detail) {
  const line = `[${new Date().toISOString()}] to=${to} subject="${subject}" success=${success} ${detail || ''}\n`;
  fs.appendFileSync(LOG_PATH, line);
}

// ══════════════════════════════════════
//  SERVER
// ══════════════════════════════════════
const config = loadConfig();
const app = express();

// CORS — localhost and file:// only
app.use((req, res, next) => {
  const origin = req.headers.origin || '';
  const isLocal = !origin || origin === 'null' || origin.match(/^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/);
  if (!isLocal) {
    return res.status(403).json({ success: false, error: 'Forbidden — localhost only' });
  }
  res.header('Access-Control-Allow-Origin', origin || '*');
  res.header('Access-Control-Allow-Methods', 'POST, GET, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.sendStatus(200);
  next();
});

app.use(express.json({ limit: '10mb' }));

// Create transporter
const transporter = nodemailer.createTransport({
  host: 'smtp.gmail.com',
  port: 465,
  secure: true,
  auth: {
    user: config.email,
    pass: config.appPassword
  }
});

// ── HEALTH ──
app.get('/health', async (req, res) => {
  try {
    await transporter.verify();
    res.json({ status: 'ok', email: 'connected', account: config.email });
  } catch (e) {
    res.json({ status: 'error', email: 'disconnected', error: e.message });
  }
});

// ── SEND ──
app.post('/send', async (req, res) => {
  const { to, subject, body, attachment_path } = req.body;

  if (!to || !subject || !body) {
    return res.status(400).json({ success: false, error: 'Missing required fields: to, subject, body' });
  }

  const mailOptions = {
    from: config.email,
    to,
    subject,
    text: body,
    html: body.replace(/\n/g, '<br>')
  };

  // Attach file — from local path OR base64 data
  const { attachment_base64, attachment_name } = req.body;
  if (attachment_base64 && attachment_name) {
    console.log(`  📎 Attachment: ${attachment_name} (${Math.round(attachment_base64.length / 1024)} KB base64)`);
    mailOptions.attachments = [{
      filename: attachment_name,
      content: Buffer.from(attachment_base64, 'base64'),
      contentType: 'application/pdf'
    }];
  } else if (attachment_path) {
    const absPath = path.resolve(attachment_path);
    if (!fs.existsSync(absPath)) {
      return res.status(400).json({ success: false, error: 'Attachment file not found: ' + attachment_path });
    }
    mailOptions.attachments = [{
      filename: path.basename(absPath),
      path: absPath
    }];
  }

  try {
    const info = await transporter.sendMail(mailOptions);
    logSend(to, subject, true, 'messageId=' + info.messageId);
    console.log(`  ✓ Sent to ${to} — ${subject}`);
    res.json({ success: true, message_id: info.messageId });
  } catch (e) {
    logSend(to, subject, false, e.message);
    console.error(`  ✗ Failed to ${to} — ${e.message}`);
    res.status(500).json({ success: false, error: e.message });
  }
});

// ── START ──
app.listen(PORT, '127.0.0.1', () => {
  console.log('');
  console.log('  🐢 Terrapin Mail Server');
  console.log(`  Running on http://localhost:${PORT}`);
  console.log(`  Sending from: ${config.email}`);
  console.log(`  Log: ${LOG_PATH}`);
  console.log('');
  console.log('  Endpoints:');
  console.log('    GET  /health  — check connection');
  console.log('    POST /send    — send email {to, subject, body, attachment_path}');
  console.log('');
});
